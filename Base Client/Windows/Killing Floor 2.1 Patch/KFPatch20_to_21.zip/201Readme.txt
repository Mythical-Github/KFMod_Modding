Killing Floor ver. 2.0.1 

index:

1.1......................Installation
1.2......................Changelog
2 Aknoweldgements
2.1......................setting up a server
2.2......................Setting up waves on your server
3........................Credits

Welcome to the patch of Killing Floor, we hope that you are finding the adjustments we made pleasing and
 fun. This Readme will guide you through the installation process and may answer questions you had when
playing the last version of Killing Floor.

1.1 Installation

Just copy the files into your KFMod20 Folder. They will ask you if you want to overwrite the files
already exisitng there, and you may answer yes. The Subfolderstructure of KF is being taken into
consideration when this patch was bundled. Also, considering that there's a new KFMod20User.ini and KFMod20.ini included
you may have to change the game back to the settings you are used to, like detail, resolution player name, etc.

1.2 Changelog:

Changelog 


- Sirens now die immediately when their head is removed. 
- Added Lobby Timeout option to servers.
- Increased number of max enemies able to spawn based on difficulty. (On suicidal it gets up to 100 or so)
- Stalkers must now De-Cloak temporarily to attack, and cannot cloak if decapitated.
- The DownTime between waves (shopping time) has been extended slightly. Still scales to difficulty.
- Player accrued cash is now kept after death. Though, you lose a percentage on death, based on difficulty. (15-35%)
- Combat Shotgun now penetrates enemies and can achieve headshots - buckshot Damage re-balanced to take this into account.
- Hunting Shotgun damage toned down slightly. (70pb to 50pb)

- Persistent Player "Clones" issue when logging in and then leaving fixed. H4XxX0RED
- Winchester Ironsight works properly code-wise
- Players are forbidden to spectate other players when dead -- no more specator bug. H4XxX0RED
- Zeds attack welded doors until they are destroyed
- slightly improved AI overal
- Newly bought weapons get fully loaded H4XxX0RED
- lost weapon when bought and lost the money for it H4XxX0RED
- setanimaction in KFPawn referring to non-replicated variables fixed.
- various accessed nones fixed
- Scoreboard functional H4XxX0RED
- Whitescreen with blur on macs and linux systems no more
- fixed weight system
- 6th player unable to connect
- defect playerskins fixed (Thanks Grex 4D for the fixed upls!)
- Winchester: higher damage
- Crossbow: higher damage + ammocost 30 pounds + Prize 500 pounds
- Hunting shotgun: ammocost 30 pounds
- Bullpup + 9mm: ammocost 10 pounds
- speed now increased with 9mm, too
- Heads of zeds pointing at their targets
- range problems with the Axe fixed
- more zeds spawning with more players
- BioticsLab: Disabled collision in some of the pipes, invisible ramp to the "safe spot"
- Manor: Fixed pathing for the stairs down to the trader 
- Crossbow Zoom works like the winchesterzoom.



H4xXx0red means the fix is a very ugly hack that fixes the outcome, but not the source of the bug.

Aknowledgments:

2.1 Setting up a server:
Setting up a server is pretty easy, just use the already existing KFServer.bat within your directory
or set it up directly in game under "create server". Bear in mind, however, that 6 PLAYERS IS MAX!!!!!
Most of the servers online has a 16 Players max, but that won't work. The game just accepts 6 players
So please, in order not to confuse joining players, please set the max always to 6 players maximum. 
We thank you for your understanding.

2.2 Setting up waves:

Alright! So you want to set up your waves? Here's how:

First, look into your kfmod20.ini. There you'll have to scroll down to the caption [KFMod.KFGameType]. There you'll find the entries you have to alter.

Monsters in KF are being spawned in squads. Like the first wave consisting of squads of Bloats and Clots.

Now that we got that covered, you'll need a list from the code that explains what what monsters are, it's the MonsterClassNameArray and that this is important. See how it looks?
Code:MonsterClassName(0)="KFChar.ZombieClot" //A.
MonsterClassName(1)="KFChar.ZombieCrawler" //B.
MonsterClassName(2)="KFChar.ZombieGoreFast" //C.
MonsterClassName(3)="KFChar.ZombieStalker" //D.
MonsterClassName(4)="KFChar.ZombieScrake" //E.
MonsterClassName(5)="KFChar.ZombieFleshpound" //F.
MonsterClassName(6)="KFChar.ZombieBloat" //G.
MonsterClassName(7)="KFChar.ZombieSiren" //H.



Well, the important bit is after the // here you see what monster has what Letter. Invasion admins might think that the indices of the array are important, well they are not in KF. It will all get clear.

Now we might be to able to see what MonsterSquad[0]=1A1G2A1G1A means. It means that this squad consists of 4 clots and 2 Bloats. One could write 4A2G into the squad, too. It would have the same effect.
Here it is important that it is Squad number 0 that consists of these monsters.

Now we got that memorised,
Waves[0]=(WaveMask=1,WaveMaxMonsters=30,WaveDuration=255,WaveDifficulty=0.000000)
What does that mean?

well the index of the Waves-array is pretty easy. this is just the first wave. period

WaveMaxMonsters = Well it's obvious I guess, the maximum ammount of monsters, the Betatesters might have noticed that with more people on a server the first wave has more than 30 monsters. Well the exact ammount of monsters is calculated based on the ammount of players on the server and this number. So make this bigger, the more monsters you'll get.

WaveDuration = After this Time (it's in seconds, and the actual time is 30 plus that I think), Monsters with no direct line of sight to the player will get killed. That counts for glass too so you might have seen zombies comit suicide behind a window or a fence. The number 255 seems reasonable to me since the wavetime is long enough (over 3 minutes) and even if I put all my efforts in making the AI better, some zeds still get stuck somewhere (rather seldom now, thank god), but you want them to die then nonethless and don't wait hours for the next wave.

WaveDifficulty = Monsters making bigger damage and stuff is adjusted over the gamedifficuly the server makes. However, with this, you can set the Difficulty of the waves up through the .ini
the calculation of this is 
Code:AdjustedDifficulty = GameDifficulty + Waves[WaveNum].WaveDifficulty




well Suicide has a difficulty of 7 so a wavedifficulty of 0.5 doesn't add much more to that. But it's still a little harder...

WaveMask: You already wanted to know what this is huh? Well, I'll explain with an example. 
Say, I have 2 Squads in my ini I want to have the first wave:


MonsterSquad[0]=2A7E
MonsterSquad[4]=4F

So basically In my first wave, I want to have a squad consisting of 2 Clots and 7 Scrakes and another squads consisting of 4 fleshpounds. (I would not advice to make this your first wave, though. You'll get raped).

So, for my first wave, I'll have to set up the wavemask to make them appear. The wavemask is a number that is made of the numbers of squads you want to use. It's math, guys! The formula is
Code:2^Indexonesquad + 2^Indexanothersquad + 2^Indexwhateversquad + ....



Don't be afraid of big numbers, the game can handle them!


If you don't know how to calculate this, you can use the windows calculator.


To make them appear you have to calculate 2^0 + 2^4 = 17 That's the wavemask then:
Waves[0]=(WaveMask=17,WaveMaxMonsters=17,WaveDuration=90,WaveDifficulty=0.000000)

So it's time for some rapage!

Another thing, if you want to add more waves to your game, you will have to add the numbers to the Finalwave-entry. Another thing is, sometimes your setup won't work foe some reason,

certain monsters are not showing up, etc. In that case, try to experiment a bit, add a wave with the monster you want to add etc.

Credits:
This wonderful and fantastically informative readme was brought to you by Faust, Killing Floor is done by the Killing Floor team, if you want more
Information or leave some feedback visit the KF-forums at http://Killingfloor.freedomsnet.net

Have a nice day!