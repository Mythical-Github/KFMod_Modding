"Evil Kitten" Mesh hacked and Skinned by Syphonboa aka HumanoidTyphoon aka Vash-The-Stampede on March 21-22, 2004. syphonboa@yahoo.com or visit us at #tsr-ut2004@gamesurge.com 

Ophelia body + mercenary female head c = Better looking the Ophelia :p Yes this is the recolored Ophelia body with a recolored mercenary head. All credit goes to Atari and their crew. :) I also used the texture from the bustier for the sleeves. Check it out if you got time to stare. :) 


This skin has both red and blue team colors. 


Files and instructions: 

evilkittenanim.ukx goes into the animations folder

evilkitten.upl goes into the system folder

evilkitten.utx goes into the textures folder

go to system folder and open up XPlayers.int in Notepad and paste this to the very bottom:

EvilKitten="Name: Bridget|Age: 21|Race: Human!|Data:|Evil Kitten is one of the primary players from the TSR clan. She is proficient in the mini-gun and the flak cannon. Don't mess with this kitty, or you'll get neutered.||"

then save it. :D ENJOY!!



Special Thanks: Atari, Unreal Development Network, Milkshape 3d, Adobe Photoshop, BrAiN and of course, Evil-Kitten!!!

Notes: This was made for Unreal 2004 but it "should" work with UT2003..and yes she SITS in the vehicles! Feel free to make more textures for this mesh, its just ophelia body and mercenary head. 