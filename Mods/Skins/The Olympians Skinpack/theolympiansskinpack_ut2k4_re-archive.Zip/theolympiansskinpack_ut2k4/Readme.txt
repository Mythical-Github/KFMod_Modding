
 ////////////////////////////
 //			   //
 // The Olympians Skinpack //
 // Ares, Poseidon, Apollo //
 //     Artemis, Athena    //
 //			   //
 ////////////////////////////


--------------------------------------------------------------------------------------------


Skins by J2a
Programs used: Upaint, Paint shop pro 7, Adobe photoshop 6.0

- Extract the .UPL files to your unreal tournament 2004 /system folder
- Extract the .UTX files to your unreal tournament 2004 /textures folder

The Olympian skinpack includes five new skins: Ares (reskin for Frostbite), Poseidon 
(reskin for Cannonball), Apollo (reskin for Torch), Artemis (reskin for Blackjack)
and Athena (reskin for Ophelia). All the skins have team colors and almost all of them 
have team faces, too. Some of them have metal shaders on them and I've also used 
transparent layers to remove some unwanted parts of the models.

Thanks to:

SaD for uploading this :)
Skincity community for the feedback ( http://skincity.beyondunreal.com/ )
and some other people which I can't remember.


If you have an older version of artemis2, replace the .utx and .upl files with the 
skinpack files.