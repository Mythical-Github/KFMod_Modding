
  -----------------------------------------

    Starsiege CYBRID Skin & Voice Pack - Unreal Tournament 2004

  -----------------------------------------


Release Date: 1/9/2020
Re-Release Date: 3/25/2021

Author: WorpeX (aka Pixel_Hunter)

Team Colors Support : Yes

Includes 3 Skins: <Corinthian-Blue>,<pLaGUe-DoG>,<Unrelent>
Includes 3 Voice Packs, each skin has its own Voice Pack

All Voice lines sourced from Starsiege. Skins designed to resemble their namesakes. 

INSTALLATION
------------

Put the Files in the Systems folder into your UT2004 Systems Directory
Put the Files in the Sounds folder into your UT2004 Sounds Directory
Put the Files in the Textures folder into your UT2004 Textures Directory

Promo is simply images you can view or discard

Thanks for downloading and enjoy!

OTHER FILES BY AUTHOR
------------
If you enjoyed this, please check out these other characters I've released:

Mass Effect Quarian
Mass Effect Turian
Mass Effect Salarian
Mass Effect Krogan
Beast Wars Airazor
Futuria & Flex (Skins)
