
  -----------------------------------------

    Mass Effect Krogan Pack - Unreal Tournament 2004

  -----------------------------------------


Release Date: 2/1/2021

Author: WorpeX
Author (Voice Packs): MJpoland

Team Colors Support : Yes

Included Characters:

Wrex
Grunt
Uvenk
Jax (Talon)
Obsidian (Custom)

INSTALLATION
------------

Put the Files in the Systems folder into your UT2004 Systems Directory
Put the Files in the Textures folder into your UT2004 Textures Directory
Put the Files in the Animations folder into your UT2004 Animations Directory

Promo is simply images you can view or discard

OTHER FILES BY AUTHOR
------------
If you enjoyed this, please check out these other characters I've released:

Mass Effect Salarian
Beast Wars Airazor
StarSiege pLaGUe-Dog, Corinthian-Blue & Unrelent (Skins)
Futuria & Flex (Skins)

I have additional Mass Effect races being worked on and I hope to have them released soon!

Thanks for downloading and enjoy!