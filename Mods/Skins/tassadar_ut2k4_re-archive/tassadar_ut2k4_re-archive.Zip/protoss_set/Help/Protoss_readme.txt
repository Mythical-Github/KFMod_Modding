07.03.03
================================================================
Model Name              : Protoss
installation directory  : UT2003\Animations, UT2003\KarmaData, UT2003\System, UT2003\Textures
Author                  : Lukas Beyeler
Sounds			: no additional sounds
Email Address           : rastaman_bey@planetquake.com
Website URL		: www.planetquake.com/afterwards

Model description       : Fenix
                          Age: 399, Race: Protoss (Templar Warrior)
                          Data: Fenix rose up through the Templar ranks alongside his close friend Tassadar.
                          He is both cunning and powerful, and has fought against the enemies of the Protoss in                           countless battles. Capable of strong empathy and tremendous rage, Fenix has proven himself to be                           one of the greatest Protoss warriors of all time.

                          Tassadar
                          Age: 356, Race: Protoss (High Templar)
                          Data: Tassadar exemplifies the growing rift within Protoss society. Born into a new generation
                          that looks ahead to a dynamic future, Tassadar is frustrated by the stoic view that his elders 
                          hold of the past. Tassadar feels that the unbending nature of the Protoss and their inability to 
                          re-evaluate ancient traditions will be the doom of this race.||Fascinated by the power and 
                          mysticism of the renegade Dark Templar caste, Tassadar hopes to find some way to bridge the gap                           between these exiles and his masters.||"


Additional Credits to   : the makers of the UT2003 character resource art packages

Thanks to               : the people at UDN for the excellent tutorials, Digital Extremes and Epic Games for
                          UT2003, the people at the Polycount message boards for helping me improve the model
================================================================
* Play Information *

New Sounds              : no
CTF Skins               : yes
LODS			: yes


* Construction *
Poly Count              : 2826
Vert Count              : 1626
Skin Count              : 2 default skin, 4 CTF skins
Base info               : The mesh and the skin are done from scratch. The bip skeleton is a modified version
                          of the Alien skeleton provided in the UT2003 character resource art package. 
                          Some of the animations are also based on the animations provided in this package, but
                          all are essentially modified.
Software used           : 3dsMAX 4.2, Adobe Photoshop 5.5
Known Bugs              : no known
Build/Animation time    : 8 weeks


* How to use this model *

Unpack the zip file in your UT2003 directory (e.g. c:\UT2003), the files are copied automatically in the
following directories:
Protoss.ukx: UT2003\Animations
Protoss.ka: UT2003\KarmaData
ProtossPL.upl: UT2003\System
PrptossSkin.utx: UT2003\Textures

To get the bios working, open XPlayers.int (in the UT2003\System directory) with a simple text editor.
Copy the following 2 lines (also enclosed in Bios.txt) at the bottom of the XPlayers.int file:

Fenix="Name:  Fenix|Age:   399|Race:  Protoss|         (Templar Warrior)||Data:|Fenix rose up through the Templar ranks alongside his close friend Tassadar.||He is both cunning and powerful, and has fought against the enemies of the Protoss in countless battles. Capable of strong empathy and tremendous rage, Fenix has proven himself to be one of the greatest Protoss warriors of all time.||"
Tassadar="Name:  Tassadar|Age:   356|Race:  Protoss|         (High Templar)||Data:|Tassadar exemplifies the growing rift within Protoss society. Born into a new generation that looks ahead to a dynamic future, Tassadar is frustrated by the stoic view that his elders hold of the past. Tassadar feels that the unbending nature of the Protoss and their inability to re-evaluate ancient traditions will be the doom of this race.||Fascinated by the power and mysticism of the renegade Dark Templar caste, Tassadar hopes to find some way to bridge the gap between these exiles and his masters.||"


* Copyright / Permissions *

Unreal Tournament 2003 is a registered trademark of Digital Extremes and Epic Games


Edited by SGO for UT2004
