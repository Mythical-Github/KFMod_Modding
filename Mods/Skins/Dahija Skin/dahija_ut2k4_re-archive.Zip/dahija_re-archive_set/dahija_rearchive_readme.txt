2,23,2017
dahija re-archive

     Unreal Tournament 2003/2004 Model

      *************************************
        Name              : Dahija                
        Version           : 1.00                      
        Release Date      : Juli 2005     
        Filename          : dahija.zip
        T/C               : yes              
        Author            : APOPTOID               
        Email Address     : apoptoid@yahoo.de 
        Homepage          : http://apoptoid.de
        Software used     : Maya 5.0, Photoshop 7.0, UnrealED 3.0

the archive of this model is intact.  :)  it's smooth and thin and runs well in the game.  :|
-M kusanagi

M kusanagi is available at:
  1.M kusanagi channel on youtube
  2.M kusanagi on google+ profile