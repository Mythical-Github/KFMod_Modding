
  -----------------------------------------

    Mass Effect Salarian Pack v1.1 - Unreal Tournament 2004

  -----------------------------------------


Release Date: 4/17/2021
Version: 1.1

Author: WorpeX
Author (Mordin Voice Pack): MJpoland

Team Colors Support : Yes

Included Characters:

Mordin Solus
Commander Kirrahe
Councilor Valern
Jaroth (Eclipse)
Commander Rentola
Dr. Omnos Saleon
Skiddle

INSTALLATION
------------

Put the Files in the Systems folder into your UT2004 Systems Directory
Put the Files in the Textures folder into your UT2004 Textures Directory
Put the Files in the Animations folder into your UT2004 Animations Directory

Promo is simply images you can view or discard


CHANGE LOG
------------

v1.1:
Added Detail Textures
Added Metal FX shading to armor
New Salarian Character: Skiddle
Created Kirrahe Voice Pack (Used by Kirrahe, Valern & Rentola)
Created Jaroth Voice Pack (Used by Jaroth & Omnos)
New Portrait for Mordin
Animated Portraits for all 7 characters
UPL File Tweaks


OTHER FILES BY AUTHOR
------------
If you enjoyed this, please check out these other characters I've released:

Mass Effect Quarian
Mass Effect Turian
Mass Effect Krogan
Beast Wars Airazor *RECENTLY UPDATED*
StarSiege pLaGUe-Dog, Corinthian-Blue & Unrelent (Skins) *RECENTLY UPDATED*
Futuria & Flex (Skins)

Thanks for downloading and enjoy!