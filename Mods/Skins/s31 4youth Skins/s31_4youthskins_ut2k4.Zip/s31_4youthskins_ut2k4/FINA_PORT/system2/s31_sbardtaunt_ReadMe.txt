+-----------------------------------------------------------------------------------------------+
| TITLE:    s31_4youthskins2                                                                    |
+-----------------------------------------------------------------------------------------------+
| AUTHOR:   M kusanagi                                                                          |
|                                                                                               |
|                                                                                               |
| DATE:     N/A                                                                                 |
| BUILD:    0                                                                                   |
| GAME:     Unreal Tournament 2004                                                              |
+-----------------------------------------------------------------------------------------------+
| FILES:    s31_sbardtaunt.u                                                                    |
|           s31_sbardtaunt.int                                                                  |
|           s31_sbardtaunt_ReadMe.txt                                                           |
+-----------------------------------------------------------------------------------------------+
| SOUNDS:   ACKS:    0    FFIRES:  0  NAMES:   0                                                |
|           ORDERS:  0    OTHERS:  0  TAUNTS:  8                                                |
|           TOTAL UNIQUE:  8                                                                    |
+-----------------------------------------------------------------------------------------------+
| UTILITY:  This package was built with UT2K4VoicePackager by Paul Catalano (www.xgxlan.com/vp) |
+-----------------------------------------------------------------------------------------------+

TO INSTALL (MANUALLY):
Place the .u and .int files in the System directory of Unreal Tournament 2004.
For use on a server, add the following lines to the UT2004.ini file found in
 the System directory of Unreal Tournament 2004, under the section [Engine.GameEngine]:
ServerPackages=s31_sbardtaunt

TO INSTALL (UT4MOD):
Running the UT4MOD file will install the files into their correct locations.
Choose the "Modify UT2004.ini" option to automatically add the line
ServerPackages=s31_sbardtaunt to the UT2004.ini file.
If the UT4MOD file will not run (a problem with the file type association),
the command is:  X:\PATH_TO_UT2004\System\Setup.exe install PATH_TO_UT4MOD
