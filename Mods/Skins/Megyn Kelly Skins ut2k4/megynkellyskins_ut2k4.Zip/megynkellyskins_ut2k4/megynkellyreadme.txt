12,20,2016 * * * megynkellyskins_ut2k4 package
skins by M kusanagi
with all the national hype on megyn kelly anchor demise, M kusanagi saw an interesting influx thru the things that are, and the things that will be.  this twin pack of kelly and her wickedly evil sister side-kick was the answer to many of unreal's dreams, predictions, and prayers.
(c) copyright 2016, by M kusanagi
all rights reserved therein for "megyn_kelly_fox", and "megyn_kelly_pro" by M kusanagi, epic, atari, unreal tournament, unreal tournament 2004, and their affiliates.  any other use than installed play entails fraud.  as per epic's client agreement, electronically exchanging packages that have not been changed, altered, or divided for profit is encouraged.

----
  1.UPL files are placed in user's system folder.
  2.UTX files are placed in user's texture folder.
  3.README and JPEG are placed in user's help folder.
----
head hunters beware!!

-M kusanagi

M kusanagi is available at:
  1.M kusanagi channel on youtube
  2.M kusanagi on google+ profile