
  -----------------------------------------

    Mass Effect Turian Pack v1.1 - Unreal Tournament 2004

  -----------------------------------------


Release Date: 2/4/2021
v1.1 Release Date: 4/20/2021

Author: WorpeX
Author (Garrus Voice Pack): MJpoland

Team Colors Support : Yes

Included Characters:

Garrus Vakarian
Councilor Sparatus
Lantar Sidonis
Nihlus Kryik
General Septimus
Veltrax Nil

INSTALLATION
------------

Put the Files in the Systems folder into your UT2004 Systems Directory
Put the Files in the Textures folder into your UT2004 Textures Directory
Put the Files in the Animations folder into your UT2004 Animations Directory

Promo is simply images you can view or discard

CHANGE LOG
------------

v1.1:
Added Detail Textures
Added Metal FX shading to armor
Added Light FX to Garrus, Nihlus & Oraka
Created Turian Boss Voice Pack
Replaced Oraka's face texture with game accurate one
New Portrait for Oraka, Nihlus, Garrus and Sparatus
Animated Portraits for all 6 characters
New Garrus Texture
UPL File Tweaks


OTHER FILES BY AUTHOR
------------
If you enjoyed this, please check out these other characters I've released:

Mass Effect Quarian 
Mass Effect Salarian
Mass Effect Krogan
Beast Wars Airazor
StarSiege pLaGUe-Dog, Corinthian-Blue & Unrelent (Skins)
Futuria & Flex (Skins)

I have additional Mass Effect races being worked on and I hope to have them released soon!

Thanks for downloading and enjoy!