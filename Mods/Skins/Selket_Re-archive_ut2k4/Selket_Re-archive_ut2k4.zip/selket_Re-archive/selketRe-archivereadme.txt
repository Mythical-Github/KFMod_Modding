uploaded to UTzone by M kusanagi, 4-23-2019.
the archive is intact.  this great skin/model
was downloaded from an obscure UT2k4 site in Russia.
there was no readme, and the material has been
imbeded into the model, so to extract the .utx,
you'll probably have to use umodel.  runs great.
and bot use is at 3, so if you don't want it in
random call-up, change this .upl setting to zero.
-M kusanagi
//===
the model's body is Diva, but the head is unknown.