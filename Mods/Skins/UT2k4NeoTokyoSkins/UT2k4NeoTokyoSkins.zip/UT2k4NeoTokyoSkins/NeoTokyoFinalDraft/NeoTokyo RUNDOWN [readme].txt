//
	NeoTokyo Mod for UT2k4 is downloadable at [Mod DB].
//
	below is the description of this Mod at [Mod DB].
//
	"NEOTOKYO is a first person shooter that aims to provide a visceral combat experience in a rich near future setting. The setting emulates combat between two cybernetically enhanced special operations groups, introducing augmentations such as thermoptic "active" camouflage and networked IFF (Identify Friend or Foe) systems to the urban close quarters combat genre. Players take the role of two opposing forces, the JINRAI and the IM-NSF (Interior Ministry National Security Force)".
--------------in other words, Government versus Military.
//
************************************************************
//
	AS OF TODAY, sunday, december 15, the package [6 PlayerModels from the mod] has been run for several hours on more than a couple of days.
//
	originally, the models consisted of Animations [.ukx] and Textures [.utx], but had no Descriptions [.int] or System file [.upl] to connect them with the Unreal Game Platform.  also, 6 Portrait Images were needed [these were added to the Textures], so Bot Configuration could find them for play activation.
//
	the models and the incomplete materials, only, came from the NeoTokyo Mod.  i've written [added .int] a Description for the 6 models [3 Military in Armor, 3 Government in Fatigues], scripted a System file to link the .ukx with the .utx, added 6 Portraits to the original .utx, made some package art-work for this upload [the included PNG was at the Mod site, however], and made the 2 female models slightly quick and spry, by compiling a SPECIES system file [Species_Specialist.u].
//
	THIS ARCHIVE, was reconstructed by M Kusanagi, 2019.  who ever built the original NeoTokyo Mod, is the owner of all the raw data.  i just claim to have done all the reconstruction parts, so that it can be used for play in the game platform [UT2k4], independently, of its large NeoTokyo Mod for UT2004, installtion.  this package [PlayerModels here] can NOT be sold or exchanged for profit.  but it can be electronically mailed and shared and re-uploaded, if this readme is part of that upload.  :)  -msi  	ps.  i can be found at my YouTube account.
//
************************************************************
//
01.	SOME THINGS TO KNOW ABOUT THE NEOTOKYO MOD, BELOW
/
/
	the NeoTokyo game description says that it's 2 sides which fight over 2 control points [like the DOM gametype], but as 1 side controls both points, the other side can't respawn.  this means that 1 of the points must be taken, or your side can get killed until no one is left.
//
02.	BELOW IS A COMMENT [at the mod site, Mod DB] WHICH EXPLAINS SOME OF NEOTOKYO'S HISTORY
/
/
	"This UT2004 mod is sort of like an alpha release which was later ported to Source engine as a Half-Life 2 mod. It looks pretty cool, I like the asian theme in the levels. User interface is also much better than KFMod's. Sadly, the source codes seem to have been stripped".
//
03.	AN UNIMPLEMENTED MODEL IMPROVEMENT THAT DIDN'T REACH FRUITION, BELOW
/
/
	"RequiredWeapon" in the UnrealPawn Class, could possibly be used for ThermOptics and NightVision by extending the SPECIES_Type Class [spawn_invis_combo, spawn_tranlocator].  however, i found this to be too challenging of a task, for the moment.  perhaps on another day.
//
04.	KNOWN ISSUES
/
/
	-- not tested online --
	-- no team skins --
//
05.	DIRECTIONS FOR MANUAL INSTALLATION
/
/
--------------Package:  NeoTokyo Models-----------------
/
/
	--Animation folder contents [.ukx] is placed in the Animations folder of your UT2004 Directory.
	--artwork folder contents [various images] is placed in the Help folder of your UT2004 Directory.
	--System folder contents [.upl, .u, .int] is placed in the System folder of your UT2004 Directory.
	--Textures folder contents [.utx] is placed in the Textures folder of your UT2004 Directory.
	--readme can also be placed in the help folder, since it has a title, and can then be found later.
//
06.	THE ORIGINAL ARCHIVE IS HERE INTACT [the model files only]
/
/
	however, i could find no simple readme per se, although i never opened the entire game into my UT2004 Directory, so a copy to put in this Archive didn't materilize.  below is the only map description that had any real meat to it:
	"Intelligence indicates new 'Ghosting' technology being developed by Shinkuu Kon Corporation at a low level facility just outside NEOTOKYO-SubSector Shusen 3. Material components used in the process are being stored in a nearby storage facility".
/
//
end