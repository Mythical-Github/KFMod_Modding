readme=4,13,18
"Spaceworms" was conceived 2 years ago, but there has been no time for completion with all the deathmatch audits [over 1,400 DM maps].
today we prepare to make it available, since it's just not fair to let down the ut2k4 community, month after month.  we need fresh meat.  package "Spaceworms", is the answer.
***
***special thanks to kat bits, for the raw PSK from their site.  it "linked-up" with existing animations perfectly.
>>>
>>>
all art, scripting, and "link-up" (c) copyright 2018, by M kusanagi
>>>
>>>
all rights reserved therein for "Spaceworms",
by M kusanagi, epic, atari, unreal tournament, unreal tournament 2004, and their affiliates.  
any other use than installed play entails fraud.  as per epic's client agreement, 
electronically exchanging packages that have not been changed, altered, or divided for 
profit is encouraged.  -M kusanagi
>>>
author's note:
Karma Tube is available at kat bits.  so don't just change the texture [material] or system ratings, and call it yer spaceworm, that's just rude and un-neighborly.
==frag 'em high!!==  :0
>>>
INSTALATION
___________
Animations folder to Animations folder
System folder to System folder
Textures folder to Textures folder
Help folder to Help folder
>>>

M kusanagi is available at:
  1.M kusanagi channel on youtube
  2.M kusanagi on google+ profile