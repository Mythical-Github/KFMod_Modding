---------------------------------------------
Jefe's Wireframe skin pack v 0.4



---------------------------------------------
What you're getting, and some notes:



Wireframe skins for all the Epic player models now including Xan and Axon. Additionally, I've added skins for skeletons included in the game.  I've separated the upls into a default pack and a ECE pack.  Something like 90 characters in total.  This version is fully compatible with the Hologram Skin pack.

All of the skins include 4 team colors. 

---------------------------------------------
Version History:



0.4 - Re-release of the Wireframe Skinpack.  (2014-01-10)  So..... I was reuploading a lot of my old stuff and decided to fix a small issue with 0.3.  The main change to this old skin pack is to remove the entries for Picard and Taye so they do not conflict with the Hologram Skin pack (v1.1). The wire pack is different enough from the holo pack that I think it deserves a re-release on its own merits.  Enjoy!

1.1  Minor bug fix.  (2009-07-24) (Hologram Skin Pack) Added a blue team skin for the blue holo material. Added a few solid color variants for the two-toned characters. (Cylon, Raptor, Junkyard Mech.)  If you are upgrading from 1.0, delete the old HologramV1.utx and HologramV1ECE.utx files, and extract the new ones, HologramV1_1.utx and HologramV1_1ECE.utx. Extract the new upls, which will overwrite the old ones. All other files are unchanged.  

1.0 - Official Release. (2009-07-23)  Now known as the Hologram Skin Pack rather than Wireframe Skin Pack.  Completely redid nearly every component of the old pack, hence the new name.  The 0.3 version and the current version aren't mutually exclusive; you can have both sets installed if you wish.  The only overlapping character names are those of Picard and Taye, which of course can be renamed.

0.3 - beta.  (2008-11-5) Numerous improvements.  Adjusted the color values of the various skins to be more consistent.  Created player portraits by combining the normal portraits with a wire shader effect (More time consuming than you might think.)  Changed characters from a default green color to one of four colors. Since most of the "races" in UT2004 follow a pattern of AA AB BA BB, I added additional characters where appropriate to continue the pattern. Most of the names I used are from UT99, while some where from unused entries in xplayers.int.  Also created simple characters for a two of the missing xplayers.int characters (Picard: Jakob's head, Othello's body  and Taye: Othello's head, Riker's body.) Created character descriptions.  Removed CBP2 characters.

0.2 - beta.  (2008-09-17) Discovered an error in the texture file that broke the skin pack.  Fixed and added CPB2 glumpf and karaash.  The other original CBP2 model, Goth Girl, was not included because of a 3rd texture, similar to Xan/Axon.  The othe CBP2 characters of of epic models, so i didn't include them either. 

0.1 - beta.  (2008-09-16) first beta.  Need to improve player portraits for skeletons.  Need to include instructions for creating wireframe version of custom models.  



---------------------------------------------
How to Install:


Extract Xan_twotex.ukx ........ to UT2004/Animations
Extract wire3.utx ............. to UT2004/Textures
Extract xplayerswire3DEF.upl .. to UT2004/System
Extract xplayerswire3ECE.upl .. to UT2004/System (ECE characters)
Extract XPlayersWire3.int ...... to UT2004/System   

You're done. :)



---------------------------------------------
Credits:



Epic for the shiny specular texture.   

Animation file is based on the version extracted by :TsT:Engine for the skin EXan, which you can download here:
http://skincity.beyondunreal.com/?section=skins&action=show_infos&id=2395   

Killer909 for bringing the error in beta 1 to my attention.  



---------------------------------------------
Permissions:



You can use these textures for whatever.  If you release something using them or based on them, credit me, that's all I ask.



---------------------------------------------
Author: Jefe (xfire: jefejefejefe, Youtube: reidevjord, http://wiki.tockdom.com/wiki/Jefe, Jefe on the Epic Games messageboard -  http://forums.epicgames.com/)



Other mods by author: 

Mario Kart Wii 
Rooster Island http://wiki.tockdom.com/wiki/Rooster_Island
F-Zero White Land I http://wiki.tockdom.com/wiki/F-Zero_White_Land_I
F-Zero Big Blue http://wiki.tockdom.com/wiki/F-Zero_Big_Blue
Rezway II (With Trent Rez) http://wiki.tockdom.com/wiki/Rezway_II
Psyduck Cliffs http://wiki.tockdom.com/wiki/Psyduck_Cliffs
Slot Circuit http://wiki.tockdom.com/wiki/Slot_Circuit

Unreal Tournament 2004
Some of my Skins: http://www.gametracker.com/clan/D-E-K/forum.php?thread=45164
Some of my Maps: http://mapraider.com/member/?memberid=7506
Geodude Monsters: http://forums.epicgames.com/threads/809943
AngelMapper Halloween 2011: http://forums.epicgames.com/threads/840991
DM-GoldenEye007Caves http://forums.epicgames.com/threads/939055
DM-PerfectDarkTemple http://forums.epicgames.com/threads/702253


