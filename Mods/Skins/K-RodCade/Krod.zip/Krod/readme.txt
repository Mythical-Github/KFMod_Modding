K-Rod by Slaughter

new pack includes support for 4 team game types

to install place the ukx file into your ut2004 animations folder
the upl & int into your ut2004 systems folder
and the ut into your ut2004 textures folder

enjoy