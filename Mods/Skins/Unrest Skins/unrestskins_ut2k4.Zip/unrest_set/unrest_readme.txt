3,29,17 from the studios of painted green come:

***********   ***********        *            *          *
     *        *                 * *          * *        * *
     *        *                *   *        *   *      *   *
     *        *               *     *      *     *    *      *
     *        *****          *       *     *      *  *       *
     *        *              * * * * *     *        *        *
     *        *              *       *     *        *        *
     *        *              *       *     *        *        *
     *        *              *       *     *        *        *
     *        ***********    *       *     *        *        *


UNREST.


Gurtic,
Necryss,
Burnt,
Pernyn,
Everii,

now available to fight for you (in the tourney of course  :0).

NO TEAM SKINS.

made by M kusanagi (many days) and contributing artists Blyzard (who got ut99 
models brought up to ut2k4 platform specs and standards.  :)

do you what yuz want with these models, HOWEVER!!!  dunt just upload them back
to the net with yer name on them claiming yuz made them.  :|  that's all.  :)

author's note:  the models' fade to death res des is blocked by an unclean psk command.  this means that the models won't be fully invisible when using this key binding, as well.  

just tell them:  "unrest don't need no stinking badge!"  they'll get it.  
also the entire team has an accuracy of +3, so using them officially will cost
a little more.  :)

-M kusanagi

M kusanagi is available at:
  1.M kusanagi channel on youtube
  2.M kusanagi on google+ profile