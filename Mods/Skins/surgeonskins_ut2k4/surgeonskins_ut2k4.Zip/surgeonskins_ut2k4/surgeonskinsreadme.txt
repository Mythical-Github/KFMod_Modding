8,27,2016 * * * surgeonskins_ut2k4 package
skins by M kusanagi
these 3 skins and upgrades were archived a couple of years back.  since M kusanagi has several different packages, maps, and full models spawning in the labs of painted green, this 3 skin pack will serve as an emerging horizon for the ut2k4 community.
(c) copyright 2016, by M kusanagi
all rights reserved therein for "surgeon", "hour_glass", and "lastmatch" by M kusanagi, epic, atari, unreal tournament, unreal tournament 2004, and their affiliates.  any other use than installed play entails fraud.  as per epic's client agreement, electronically exchanging packages that have not been changed, altered, or divided for profit is encouraged.

----
  1.UPL files are placed in user's system folder.
  2.UTX files are placed in user's texture folder.
  3.README and JPEG are placed in user's help folder.
----
let the frag-time begin!!

-M kusanagi

M kusanagi is available at:
  1.M kusanagi channel on youtube
  2.M kusanagi on google+ profile